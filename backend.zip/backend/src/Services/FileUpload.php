<?php
declare(strict_types=1);

namespace App\Services;

use App\Config\Uploads;

/**
 * All photos on disk:
 *   uploads/images/<prefix>-<field>-<ms>-<rand>.ext
 *
 * Naming = Cloudinary public_id style (same as Node multer):
 *   {filePrefix}-{fieldName}-{Date.now()}-{randomInt}.{ext}
 *   e.g. sensor-temp-temp_sensor_image-1726748400123-987654321.jpg
 *
 * DB stores: uploads/images/<filename>
 * Fetch URL:  {API_ORIGIN}/uploads/images/<filename>
 */
final class FileUpload
{
    public const FOLDER = 'images';

    /**
     * @param array{tmp_name: string, name: string, type?: string} $file
     * @param string $folder  ignored (call-site compatibility)
     */
    public static function save(array $file, string $folder = 'images', string $prefix = 'file', ?string $fieldName = null): string
    {
        Uploads::ensureImageFolder();

        $destDir = Uploads::root() . DIRECTORY_SEPARATOR . self::FOLDER;
        if (!is_dir($destDir)) {
            @mkdir($destDir, 0775, true);
        }

        $field = trim((string) ($fieldName ?: 'photo'));
        $field = preg_replace('/[^a-zA-Z0-9_-]/', '_', $field) ?: 'photo';

        $uniqueSuffix = (string) (int) round(microtime(true) * 1000) . '-' . (string) random_int(0, 1_000_000_000);

        $ext = pathinfo((string) ($file['name'] ?? ''), PATHINFO_EXTENSION) ?: 'jpg';
        $ext = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $ext) ?: 'jpg');

        $filename = "{$prefix}-{$field}-{$uniqueSuffix}.{$ext}";
        $dest = $destDir . DIRECTORY_SEPARATOR . $filename;

        if (!move_uploaded_file($file['tmp_name'], $dest)) {
            if (!@copy($file['tmp_name'], $dest)) {
                throw new \RuntimeException('Failed to save uploaded file.');
            }
        }

        return 'uploads/' . self::FOLDER . '/' . $filename;
    }
}
